//support.cpp

#include"provided.h"
#include "support.h"
int check_smart(const Scaffold& s, int m_l, int m_c, int N, char player) { //int check_win(Scaffold& s, int a, int b, int N, char player)
    int is_win = 0;
    int d;
    for (int l = 0; l < m_l; l++) {

        for (int k = 0; k < m_c; k++) {
            d = k;
            if (k + N - 1 <= m_c) {
                int is_line = 0;
                for (int t = 0; t < N; t++) {
                    if (s.checkerAt(l, k + t) == player) {
                        is_line++;
                        if (is_line == N - 1 && k + t + 1 <= m_c && s.checkerAt(l, k + t + 1) == VACANT) {

                            return k + t + 1;
                        }
                    }

                }



            }
            if (l + N - 1 <= m_l) { //l + N - 1 <= m_l
                int is_column = 0;
                for (int t = 0; t < N; t++) {
                    if (s.checkerAt(l + t, k) == player) {
                        is_column++;
                        if (is_column == N - 1 && l - 1 >= 0 && s.checkerAt(l - l, k) == VACANT) {

                            return k;
                        }
                    }

                }

            }


            if (l + N - 1 <= m_l && k + N - 1 <= m_c) {
                int is_h = 0;
                for (int t = 0; t < N; t++)
                    if (s.checkerAt(l + t, k + t) == player) {
                        is_h++;
                        if (is_h == N - 1 && k - 1 >= 0 && l - 1 >= 0 && s.checkerAt(l - l, k - 1) == VACANT) {

                            return k - 1;
                        }
                    }

            }




            if (l + N - 1 <= m_l && k - N + 1 >= 0) {
                int is_v = 0;
                for (int t = 0; t < N; t++) {
                    //if(m_v[l-t][k] == player && m_v[l-1][k-1] == player && m_v[l-2][k-2] == player ){
                    if (s.checkerAt(l + t, k - t) == player) {
                        is_v++;
                        if (is_v == N - 1 && k + t + 1 <= m_c && l - 1 >= 0 && s.checkerAt(l - 1, k + 1) == VACANT)
                            return k + 1;
                    }

                }//end for
            }


        } //end for m_c

    }//end for m_l
    return  d;
}


