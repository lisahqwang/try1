#ifndef SUPPORT_H
#define SUPPORT_H
int check_smart(const Scaffold& s, int m_l, int m_c, int N, char player);

#endif